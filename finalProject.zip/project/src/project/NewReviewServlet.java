package project;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


@WebServlet("/NewReviewServlet")
public class NewReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		String username = user.getName();
		String profname = request.getParameter("profname");
		String ratingText = request.getParameter("ratingContent");
		String rating = request.getParameter("ratingnumericvalue");
		String section = request.getParameter("courseSection").toUpperCase();
		System.out.println(profname);
		System.out.println(ratingText);
		System.out.println(rating);
		

		try {
			MongoClient client = new MongoClient("localhost", 27017);
			//String connectPoint = client.getConnectPoint();
			System.out.println("Server connection successful");
			
			MongoDatabase dbs = client.getDatabase("RMUSC");
			System.out.println("Connected to database successful");
			System.out.println("Database: " + dbs.getName());
			
			// Inserting into the collection
			MongoCollection<Document> collection = dbs.getCollection("testreview");
			Document query2 = new Document();
			query2.put("profname", profname);
			Document doc2 = collection.find(query2).first();
			if (doc2 == null) {
				System.out.println("There is no professor by that name");
				request.getRequestDispatcher("reviews.jsp").forward(request, response);
			}
			
			
			//Query
			Document query = new Document();
			query.put("username", username);
			query.put("profname", profname);
			
			
			// First see if that user exists by email
			Document doc =  collection.find(query).first();
			System.out.println(doc);
			if (doc == null) {
				// review does not exist yet
				// store new document
				doc = new Document("_id", (int)collection.count())
						.append("username", username)
						.append("profname", profname)
						.append("rating", rating)
						.append("ratingText", ratingText).append("section", section);
				collection.insertOne(doc);
				System.out.println("New review inserted");
			} else {
				System.out.println("Am i ever in this code block");
				int id_ = doc.getInteger("_id");
				System.out.println(id_);
				collection.findOneAndDelete(doc);
				
				doc = new Document("_id", id_)
						.append("username", username)
						.append("profname", profname)
						.append("rating", rating)
						.append("ratingText", ratingText).append("section", section);
				collection.insertOne(doc);
				
				System.out.println("Old review updated");
			}
			
			client.close();
			response.sendRedirect("reviews.jsp");
		} catch (Exception e) {
			
		}		
	}
}